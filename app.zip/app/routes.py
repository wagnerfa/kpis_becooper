# app/routes.py
import os, csv
from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from werkzeug.utils import secure_filename
from sqlalchemy import text
from . import db
from .models import TrResultado

bp = Blueprint('main', __name__)
ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(fn):
    return '.' in fn and fn.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@bp.route('/ping')
def ping():
    # testa a conexão SQLAlchemy/PyMySQL
    db.session.execute(text('SELECT 1'))
    return 'pong', 200

@bp.route('/', methods=['GET', 'POST'])
def upload_tr_resultado():
    if request.method == 'POST':
        f = request.files.get('csv_file')
        if not f or not allowed_file(f.filename):
            flash('Selecione um arquivo .csv válido.', 'danger')
            return redirect(request.url)

        upload_dir = os.path.join(current_app.instance_path, 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        filename = secure_filename(f.filename)
        path = os.path.join(upload_dir, filename)
        f.save(path)

        registros, errors = [], []
        with open(path, newline='', encoding='utf-8') as fp:
            reader = csv.DictReader(fp)
            for i, row in enumerate(reader, start=1):
                try:
                    reg = TrResultado(
                        Tr_ResultadoID         = int(row['Tr_ResultadoID']),
                        Tr_ResultadoAno        = int(row['Tr_ResultadoAno']),
                        Tr_ResultadoMes        = row['Tr_ResultadoMes'],
                        Tr_ResultadoConta      = row['Tr_ResultadoConta'],
                        Tr_ResultadoOrcado     = row.get('Tr_ResultadoOrcado')     or None,
                        Tr_ResultadoRealizado  = row.get('Tr_ResultadoRealizado')  or None,
                        Tr_ResultadoRealAntxAtu= row.get('Tr_ResultadoRealAntxAtu')or None,
                        Tr_ResultadoRealxOrc   = row.get('Tr_ResultadoRealxOrc')   or None,
                        Tr_ResultadoAnoAnterior= row.get('Tr_ResultadoAnoAnterior')or None,
                    )
                    registros.append(reg)
                except Exception as e:
                    errors.append(f"Linha {i}: {e}")

        if errors:
            flash('Erros no CSV:<br>' + '<br>'.join(errors), 'danger')
        else:
            db.session.bulk_save_objects(registros)
            db.session.commit()
            flash(f'{len(registros)} registros importados com sucesso!', 'success')

        return redirect(url_for('main.upload_tr_resultado'))

    # GET: mostra últimos 50 registros
    ultimos = (
        TrResultado.query
        .order_by(TrResultado.Tr_ResultadoID.desc())
        .limit(50)
        .all()
    )
    return render_template('upload.html', resultados=ultimos)
