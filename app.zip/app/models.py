# app/models.py
from . import db

class TrResultado(db.Model):
    __tablename__ = 'Tr_Resultado'
    Tr_ResultadoID          = db.Column(db.BigInteger, primary_key=True)
    Tr_ResultadoAno         = db.Column(db.SmallInteger, nullable=False)
    Tr_ResultadoMes         = db.Column(db.String(20), nullable=False)
    Tr_ResultadoConta       = db.Column(db.String(120), nullable=False)
    Tr_ResultadoOrcado      = db.Column(db.Numeric(14,2))
    Tr_ResultadoRealizado   = db.Column(db.Numeric(14,2))
    Tr_ResultadoRealAntxAtu = db.Column(db.Numeric(9,4))
    Tr_ResultadoRealxOrc    = db.Column(db.Numeric(9,4))
    Tr_ResultadoAnoAnterior= db.Column(db.Numeric(14,2))
